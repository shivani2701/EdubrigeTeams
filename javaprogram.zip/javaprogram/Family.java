class Family{

public static void main(String args[])
{
String m = "Malti Yashwant Shinde";
String f="Yashwant Ramchandra Shinde";
int a =21;
int s =50000;
int p=1234567890;
String ad ="at-Shindewadi,tal-Phaltan, country-India";
System.out.println("Mother name ="+m);
System.out.println("Father name ="+f);
System.out.println("Age ="+a);
System.out.println("Salary ="+s);
System.out.println("Phone number ="+p);
System.out.println("Address ="+ad);
}
}