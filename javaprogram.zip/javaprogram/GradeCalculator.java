import java.util.Scanner;
class GradeCalculator
{
public static void main(String args[])
{
Scanner sc=new Scanner(System.in);
System.out.print("Enter the salary:");
int salary=sc.nextInt();
int num=0;
if(salary>=70000 && salary<100000){
num=1;    }
else if(salary>=50000 && salary<70000){
num=2;    }
else if(salary>=30000 && salary<50000){
num=3;    }
else if(salary>=100000 || salary<30000){
num=4;    }
switch(num)
{
case 1:
System.out.println("Grade A");
break;
case 2:
System.out.println("Grade B");
break;
case 3:
System.out.println("Grade C");
break;
case 4:
System.out.println("No Grade");
break;
default:
System.out.println("Good Grade");
}}}
