import java.util.Scanner;

public class Compare{
public static void main(String args[])
{
Scanner sc=new Scanner(System.in);
System.out.print("Enter the value of a=");
String a=sc.nextLine();
System.out.print("Enter the value of b=");
String b=sc.nextLine();

if(a.equals(b))
{
System.out.println("Equal");
}
else{
System.out.println("Not Equal");
}}}