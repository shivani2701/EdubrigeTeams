public class Employee
{
//data
	String name;
	int age;
	String address;
	String emailid;
	int salary;
	String department;	
//code
	void attendMetting() {
		System.out.println("Metting at 12:30");
	}
	void givePresentation() {
		System.out.println("Your topic name is social media marketing");
	}
	void developSoftware() {
		System.out.println("we are develop a game");
	}
	
	void setName(String name) {
		this.name=name;
	}
	String getName() {
		return this.name;
	}
        void setAge(int age){
         this.age=age;  }
        int getAge(){
         return this.age;
        }
       void setSalary(int salary){
        this.salary=salary;}
       int getSalary(){
        return this.salary;}
	}


