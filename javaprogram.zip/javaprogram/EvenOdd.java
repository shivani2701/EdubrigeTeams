class EvenOdd
{
public static void main(String args[])
{
int a=90;
boolean b= a%2==0;
boolean c= a%2!=0;
System.out.println("Number is Even "+b);
System.out.println("Number is odd "+c);
}
}