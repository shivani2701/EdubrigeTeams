package secondpackage;
class Example4
{
public static void main(String args[])
{
System.out.println("hello 2nd package program");
}
}