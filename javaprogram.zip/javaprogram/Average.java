import java.util.Scanner;

public class Average
{
public static void main(String args[])
{
Scanner sc=new Scanner(System.in);
System.out.print("Enter the value of a=");
float a=sc.nextFloat();
System.out.print("Enter the value of b=");
float b=sc.nextFloat();

float avg=(a+b)/2;
System.out.println("The average of a and b is "+avg);
}
}
