import java.util.Scanner;

public class Example1 {

	public static void main(String[] args) {
		
		Scanner sc =new Scanner(System.in);
String [] [] Stnameaddress=new string[3][2];
for(int i=0;i<Stnameaddress.length;;i++)
{for(int j=0;j<2;j++)
{
Stnameaddress[][]=sc.next();
}
}
for(int i=0;i<Stnameaddress.length;i++)
{
for(int j=0;j<2;j++)
{
System.out.print(Stnameaddress[i][j]+" ");
}
System.out.println();
}}}