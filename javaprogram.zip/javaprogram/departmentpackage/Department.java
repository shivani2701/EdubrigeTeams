package departmentpackage;
public class Department
{
public void display()
{
String name="Computer";
System.out.println("Department name" +name);
}
}