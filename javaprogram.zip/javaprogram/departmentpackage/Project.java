package departmentpackage;
public class Project
{
public void projectInfo()
{
String projectname ="Ludo Game";
System.out.println("Project name"+projectname);
}
}