import java.util.Scanner;
public class ExampleJava {
 public static void main(String[] args) {
 Double a,b;
 Scanner scanner = new Scanner(System.in);
System.out.print("1:Add \n2:Sub\n3:Mul\n4:Div\n5:percentage\n6:Square\n7:Factorial\n8:remainder\n9:Area of rectangle\n10:Area of square\n11:Area of circle \nEnter an option = ");
 int ch= scanner.nextInt();
 
switch(ch)
	{
 case 1:
  System.out.print("Enter first number:");
   a = scanner.nextDouble();
  System.out.print("Enter Second number:"); 
   b = scanner.nextDouble();
  System.out.println("Addition of two number="+(a+b));
  break;                    
	            	 
 case 2:
   System.out.print("Enter first number:");
   a = scanner.nextDouble();
  System.out.print("Enter Second number:"); 
   b = scanner.nextDouble();
  System.out.println("Substraction of two number="+(a-b));
  break;

 case 3:
  System.out.print("Enter first number:");
   a = scanner.nextDouble();
  System.out.print("Enter Second number:"); 
   b = scanner.nextDouble();
  System.out.println("Multiplication of two number="+(a*b));
  break;

 case 4:
  System.out.print("Enter first number:");
   a = scanner.nextDouble();
  System.out.print("Enter Second number:"); 
   b = scanner.nextDouble();
  System.out.println("Division of two number="+(a/b));
  break;
	                
 case 5:
  System.out.print("Enter first number:");
   a = scanner.nextDouble();
  System.out.print("Enter Second number:"); 
   b = scanner.nextDouble();
  System.out.println("Percentage of two number="+((a/b)*100));
  break;

 case 6:
  System.out.print("Enter first number:");
   a = scanner.nextDouble();
  System.out.print("Enter Second number:"); 
   b = scanner.nextDouble();
  System.out.println("Square of 1st number="+(a*a));
  System.out.println("Square of 2nd number="+(b*b));
  break;
	                
 case 7:
  System.out.print("Enter first number:");
   a = scanner.nextDouble();
  System.out.print("Enter Second number:"); 
   b = scanner.nextDouble();
 int fact=1;
 for(int i=1;i<=a;i++){
 fact=fact*i;}
 System.out.println("Factorial of 1st number="+fact);
 int fact1=1;
 for(int i=1;i<=b;i++){
 fact1=fact1*i;}
 System.out.println("Factorial of 2nd number="+fact1);
 break;
 
case 8:
  System.out.print("Enter first number:");
   a = scanner.nextDouble();
  System.out.print("Enter Second number:"); 
   b = scanner.nextDouble();
  System.out.println("Remainder of two number="+(a%b));
  break;	                    

 case 9:
  System.out.print("Enter the length:");
   a = scanner.nextDouble();
  System.out.print("Enter the width:"); 
   b = scanner.nextDouble();
  System.out.println("Area of rectangle="+(a*b));
  break;	                
 
case 10:
 System.out.print("Enter the number:");
   a = scanner.nextDouble();
 System.out.println("Area of square="+(a*a));
 break;	            
 
case 11:
 System.out.print("Enter the radius:");
 Double r = scanner.nextDouble();
 Double pi=3.14;
 System.out.println("Area of circle="+(pi*r*r));
 break;	             
 
default:
 System.out.printf("Enter valid number 1 to 11");
 return;
  }
  }
  }