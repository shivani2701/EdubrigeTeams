class Age
{
public static void main(String args[])
{
int studage=19;

System.out.println(studage>18);
}
}