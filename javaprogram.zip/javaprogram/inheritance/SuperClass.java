package inheritance;
class SuperClass
{
void methodSuper()
{
System.out.println("I am super class method");
}
}