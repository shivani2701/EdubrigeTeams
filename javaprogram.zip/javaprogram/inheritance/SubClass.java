package inheritance;
class SubClass extends SuperClass
{
void methodSubClass()
{
Sytem.out.println("I am a sub class method");
}
}