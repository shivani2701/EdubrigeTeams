class Arithmetic 
{
public static void main(String args[])
{
int a=3,b=20,add,sub,mul,div,mod;
add=a+b;
sub=a-b;
mul=a*b;
div=a/b;
mod=a%b;
System.out.println("Addition of a & b = "+add);
System.out.println("Substraction of a & b = "+sub);
System.out.println("Multiplication of a & b = " +mul);
System.out.println("Division of a & b = " +div);
System.out.println("Mod of a & b = " +mod);
}
}