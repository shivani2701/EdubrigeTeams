class Addition
{
public static void main(String args[])
 {
   Test obj=new Test();
   obj.disp();
 } 
}
class Test
{
     static int add()  //static method
   {
     int a=10, b=20;   //local variable
     int c=a+b;
     return c;
    }
     void disp()    //Instance method
   {
     int x=add();
     System.out.println("Addition of Two number="+x);
    }
}