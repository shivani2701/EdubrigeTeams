import java.util.Scanner;
class Java2
{
public static void main(String args[])
{
Scanner obj=new Scanner(System.in);
System.out.print("Enter the string:");
String name=obj.next();//abcd 4
 String name1=name.toLowerCase();
 String rev="";
for(int i =name1.length()-1;i>=0;i--)//3
{
rev=rev+name1.charAt(i);  //""+d=d
}
System.out.println("Reversed String :"+rev);
if(rev.equals(name1))
{System.out.println("Palindrome");}
else{System.out.println("not palindrome");}
}
}