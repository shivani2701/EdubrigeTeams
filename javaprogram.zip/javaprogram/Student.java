import java.util.Scanner;
class Student{
public static void main(String args[]){
Scanner sc=new Scanner(System.in);
System.out.print("Enter a Roll No. Student:");
int roll_no=sc.nextInt();
sc.nextLine();
System.out.print("Enter a Student Name:");
String name=sc.nextLine();
System.out.print("Enter a Mark in physics:");
int p_mark=sc.nextInt();
System.out.print("Enter a Mark in chemistry:");
int c_mark=sc.nextInt();
System.out.print("Enter a Mark in computer application:");
int ca_mark=sc.nextInt();
int total_marks=p_mark+c_mark+ca_mark;
double percentage=total_marks/3.0;

String Division=" ";

if(percentage >= 60)
{Division="First";}
else if(percentage >= 50)
{Division="Second";}
else if(percentage >= 40)
{Division="Third";}
else
{Division="Fail";}
System.out.println("Total Marks="+total_marks);
System.out.println("Percentage="+percentage);
System.out.println("Division="+Division);
}}

