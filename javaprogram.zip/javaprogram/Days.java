import java.util.Scanner;
class Days{
public static void main(String args[]){
Scanner sc = new Scanner(System.in);
int number_of_Daysmonth=0;
String MonthOfName=" ";
System.out.print("Enter the Month Number:");
int month=sc.nextInt();
System.out.print("Enter the Year:");
int year=sc.nextInt();
switch(month){
case 1:
MonthOfName="January";
number_of_Daysmonth=31;
break;
case 2:
MonthOfName="February";
if((year%400==0)||((year%4==0) && (year%100!=0))){
number_of_Daysmonth=29;}
else{
number_of_Daysmonth=28;}
break;
case 3:
MonthOfName="March";
number_of_Daysmonth=31;
break;
case 4:
MonthOfName="April";
number_of_Daysmonth=30;
break;
case 5:
MonthOfName="May";
number_of_Daysmonth=31;
break;
case 6:
MonthOfName="June";
number_of_Daysmonth=30;
break;
case 7:
MonthOfName="July";
number_of_Daysmonth=31;
break;
case 8:
MonthOfName="August";
number_of_Daysmonth=31;
break;
case 9:
MonthOfName="September";
number_of_Daysmonth=30;
break;
case 10:
MonthOfName="October";
number_of_Daysmonth=31;
break;
case 11:
MonthOfName="November";
number_of_Daysmonth=30;
break;
case 12:
MonthOfName="December";
number_of_Daysmonth=31;}
System.out.print(MonthOfName + " " + year + " has " + number_of_Daysmonth + " days\n ");}}