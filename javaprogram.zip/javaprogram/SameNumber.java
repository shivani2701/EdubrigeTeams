class SameNumber
{
public static void main(String args[])
{
int a=99,b=99;
System.out.println(a==b);
}
}