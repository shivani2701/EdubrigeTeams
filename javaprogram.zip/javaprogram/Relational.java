class Relational
{
public static void main (String args[])
{
int num=20,num1=30;
System.out.println(num>num1);
System.out.println(num<num1);
System.out.println(num>=num1);
System.out.println(num<=num1);
System.out.println(num!=num1);
System.out.println(num==num1);
}

}