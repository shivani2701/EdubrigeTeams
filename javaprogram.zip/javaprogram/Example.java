import java.util.Scanner;

public class Example {

	public static void main(String[] args) {
		int [] arr= new int[3];
		Scanner scanner =new Scanner(System.in);
		int size=0;
                for(int i=0;arr.length;i++)
                {
                 arr[i]=scanner.nextInt();
                }
               for(int i=0;i<arr.length;i++)
                 {
                     size+=arr[i];
                  }
                    System.out.println(size);
   }
}