public class Solution
{
public static void main(String agrs[])
{
short x=10;
x=x*5;
System.out.print(x);
}
}