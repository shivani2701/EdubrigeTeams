class Friend
{
public static void main(String args[])
 {
   Test obj=new Test();
   obj.disp();
 } 
}
class Test
{
     static String Like()  //static method
   {
     String Fn="Priyanka";   //local variable
     return Fn;
    }
     void disp()    //Instance method
   {
     String x=Like();
     System.out.println("Friend Name="+x);
    }
}