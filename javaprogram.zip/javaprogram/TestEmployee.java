public class TestEmployee
{
public static void main(String args[])
{
Employee obj=new Employee();
Employee obj1=new Employee();

obj.setName("Shivani");
obj.setAge(21);
obj.setSalary(500000);

obj1.setName("Shivtej");
obj1.setAge(21);
obj1.setSalary(800000);

System.out.println("1st Employee name is "+obj.getName());
System.out.println("Age="+obj.getAge());
System.out.println("Salary="+obj.getSalary());

System.out.println("2nd Employee name is "+obj1.getName());
System.out.println("Age="+obj1.getAge());
System.out.println("Salary="+obj1.getSalary());

}
}