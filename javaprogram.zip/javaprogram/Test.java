import employeepackage.*;
import departmentpackage.*;
class Test
{
public static void main(String args[])
{
  Admin obj=new Admin();
  Employee obj1=new Employee();
  Manager obj2=new Manager();

  obj.show();
  obj1.display();
  obj2.info();

  Department dp=new Department();
  Project pt=new Project();

  dp.display();
  pt.projectInfo();
}
}