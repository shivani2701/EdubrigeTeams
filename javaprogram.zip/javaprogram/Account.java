class Account
{
String accountname;
int accountNumber;
String Bankname;
String Address;
int phone;
void setAccountname(String accountname){
  this.accountname=accountname;}
String getAccountname()
{return this.accountname;}

void setAccountNumber(int accountNumber){
  this.accountNumber=accountNumber;}
int getAccountNumber()
{return this.accountNumber;}

void setBankname(String Bankname){
  this.Bankname=Bankname;}
String getBankname()
{return this.Bankname;}

public static void main(String args[])
{
Account obj=new Account();
obj.setAccountname("Shivani Yashwant Shinde");
obj.setAccountNumber(7822);
obj.setBankname("SBI");

System.out.println("Account name is "+obj.getAccountname());
System.out.println("Account number="+obj.getAccountNumber());
System.out.println("Bank Name is "+obj.getBankname());
}
}