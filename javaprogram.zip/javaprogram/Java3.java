import java.util.Scanner;
class Java3
{
public static void main(String args[])
{
Scanner sc =new Scanner(System.in);
System.out.print("Enter the Number:");
int num=sc.nextInt();

int r,sum=0,temp;
temp=num;
while(num>0)
{
r=num%10;
sum=(sum*10)+r;
num=num/10;
}
System.out.println("Reversed number:"+sum);
if(temp==sum){
System.out.println("Palindrome");}
else{
System.out.println("Not Palindrome");}
}}