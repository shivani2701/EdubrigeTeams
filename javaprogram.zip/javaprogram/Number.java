class Number
{
public static void main(String args[])
{
int a=80,b=300;
System.out.println(a>100 & a>200);
System.out.println(b>100 & b>200);
}
}