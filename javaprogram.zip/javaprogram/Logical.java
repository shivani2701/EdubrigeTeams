class Logical
{
public static void main(String args[])
{
int a=29,b=38;
System.out.println(a>b && a<b);
System.out.println(a>=b || a!=b);
System.out.println(!(a<b));
}
}