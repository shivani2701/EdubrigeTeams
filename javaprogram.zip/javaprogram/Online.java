class Online{

public static void main(String args[])
{
System.out.println("         hello        ");
System.out.println("    welcome    to     ");
System.out.println("edubridge  online  classes");
} 
}