package firstpackage;
class Example3
{
public static void main(String args[])
{
System.out.println("hello 1st package program");
}
}