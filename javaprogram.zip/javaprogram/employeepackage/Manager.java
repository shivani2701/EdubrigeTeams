package employeepackage;
public class Manager
{
public void info()
{
System.out.println("Manager class");
}}