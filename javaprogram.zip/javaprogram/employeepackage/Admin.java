package employeepackage;
public class Admin
{
public void show()
{
System.out.println("Admin class");
}
}