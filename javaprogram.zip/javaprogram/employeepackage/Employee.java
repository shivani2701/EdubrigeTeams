package employeepackage;
public class Employee
{
public void display()
{
System.out.println("hello 1st package program under employee class");
}
}
