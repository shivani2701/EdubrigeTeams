import java.util.*;
class temperature{
public static void main(String args[]){
int Temp;
Scanner sc=new Scanner(System.in);
System.out.print("Enter the temperature:");
Temp=sc.nextInt();

if(Temp<0 ){
System.out.println("Freezing Weather");
}
else if(Temp<10){
System.out.println("Very Cold Weather");
}
else if(Temp<20){
System.out.println("Cold Weather");
}
else if(Temp<30){
System.out.println("Normal in Temp");
}
else if(Temp<40){
System.out.println("Hot");
}
else{
System.out.println("Its Very Hot");
}}}