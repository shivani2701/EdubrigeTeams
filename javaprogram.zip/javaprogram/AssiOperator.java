class AssiOperator
{
public static void main(String args[])
{
int a=2,b=3,c=0;
c+=20;

a+=b;
System.out.println(c);
System.out.println(a);
}
}