import java.util.*;
class Grade{
public static void main(String args[])
{
char grade;
Scanner sc=new Scanner(System.in);
System.out.print("Input the grade = ");
grade=sc.next().charAt(0);

if(grade=='E'){
System.out.println("You have chosen: Excellent");
}
else if(grade=='V'){
System.out.println("You have chosen: Very Good");
}
else if(grade=='G'){
System.out.println("You have chosen: Good");
}
else if(grade=='A'){
System.out.println("You have chosen: Average");
}
else if(grade=='F'){
System.out.println("You have chosen: Fail");
}
else{
System.out.println("You have chosen: Not Accepted");
}}}