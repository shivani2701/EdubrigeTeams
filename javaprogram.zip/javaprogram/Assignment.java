class Assignment
{
public static void main(String args[])
{
int a=4,b=15,c=0,d=60,h=90;
//a+=10;
b-=5;
c*=5;
d/=3;
h%=3;
System.out.println(a+=10);
System.out.println(b);
System.out.println(c);
System.out.println(d);
System.out.println(h);
}

}